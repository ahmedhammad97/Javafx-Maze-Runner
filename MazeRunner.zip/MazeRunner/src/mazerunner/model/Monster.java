
package mazerunner.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;


public abstract class Monster extends GameCharacter{

    public Monster(int x, int y) {
        super(x, y);
    }

    
    
}
