
package mazerunner.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;


public abstract class Gift extends GameCharacter{

    public Gift(int x, int y) {
        super(x, y);
    }

    
    
    
}
