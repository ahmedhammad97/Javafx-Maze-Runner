
package mazerunner.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;


public abstract class Wall extends GameCharacter{

    public Wall(int x, int y) {
        super(x, y);
    }

    
    
}
