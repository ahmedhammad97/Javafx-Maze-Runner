
package mazerunner.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;


public abstract class Bomb extends GameCharacter{

    public Bomb(int x, int y) {
        super(x, y);
    }

    
    
}
