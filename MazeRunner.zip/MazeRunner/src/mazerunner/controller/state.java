
package mazerunner.controller;


public interface state {
    public void doAction(Clock t);
}
