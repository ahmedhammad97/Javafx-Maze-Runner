
package mazerunner.controller;


public interface Observer {
    void update(int seconds);
}
